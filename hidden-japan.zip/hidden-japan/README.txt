# Hidden Japan – Deploy Guide (for Vercel)

1️⃣ GitHubで新しいリポジトリを作成（例：hidden-japan）
2️⃣ 「Upload files」で、このフォルダ内の全ファイルをアップロード
　　- index.html
　　- package.json
　　- src/App.jsx
　　- public/favicon.ico
　　- README.txt

3️⃣ 「Commit changes」をクリック（保存）

4️⃣ Vercel にログイン（https://vercel.com）
5️⃣ 「Add New → Project」
6️⃣ GitHubの hidden-japan リポジトリを選択
7️⃣ 設定はそのままで「Deploy」をクリック！

8️⃣ 数十秒後に自動でURLが発行されます 🎉
　　例：https://hidden-japan.vercel.app

※ Googleスプレッドシートの内容を更新すると、
　サイトにも自動で反映されます！
